﻿using GloboTicket.Services.ShoppingBasket.DbContexts;
using GloboTicket.Services.ShoppingBasket.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Distributed;
using System;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace GloboTicket.Services.ShoppingBasket.Repositories
{
    public class BasketRepository : IBasketRepository
    {
        //private readonly ShoppingBasketDbContext shoppingBasketDbContext;
        private readonly IDistributedCache distributedCache;
        public IConfiguration Configuration { get; }

        // removed "ShoppingBasketDbContext shoppingBasketDbContext" from constructor as data store
        // is being replaced by DistributedCache defined in Startup.cs
        public BasketRepository(IDistributedCache distributedCache, IConfiguration configuration)
        {
            //this.shoppingBasketDbContext = shoppingBasketDbContext;
            this.distributedCache = distributedCache;
            Configuration = configuration;
        }

        #region Serialization Helpers for Redis Cache

        public byte[] ConvertToByteArray(Object obj)
        {
            BinaryFormatter bf = new BinaryFormatter();
            try
            {
                using (var ms = new MemoryStream())
                {
                    bf.Serialize(ms, obj);
                    return ms.ToArray();
                }
            }
            catch (Exception ex)
            {
                string s = ex.ToString();
                return null;
            }
        }

        // Convert a byte array to an Object
        public Object ConvertToObject(byte[] arrBytes)
        {
            using (var memStream = new MemoryStream())
            {
                var binForm = new BinaryFormatter();
                memStream.Write(arrBytes, 0, arrBytes.Length);
                memStream.Seek(0, SeekOrigin.Begin);
                var obj = binForm.Deserialize(memStream);
                return obj;
            }
        }

        #endregion

        #region Basket Functions

        public async Task<Basket> GetBasketById(Guid basketId)
        {
            var basket = await distributedCache.GetAsync(basketId.ToString());
            if (basket != null)
                return (Basket)this.ConvertToObject(basket);
            else
                return null;
        }

        public async Task<bool> BasketExists(Guid basketId)
        {
            var basket = await distributedCache.GetAsync(basketId.ToString());
            return basket != null;
        }

        public async Task ClearBasket(Guid basketId)
        {
            await distributedCache.RemoveAsync(basketId.ToString());
        }

        public async Task<bool> AddBasket(Basket basket)
        {
            Guid g = Guid.NewGuid();
            basket.BasketId = g;

            return await SaveChanges(basket);
        }

        public async Task<bool> SaveChanges(Basket basket)
        {
            byte[] serializedBasket = ConvertToByteArray(basket);

            int cacheDuration = int.Parse(Configuration["CacheDurationMinutes"]);

            var options = new DistributedCacheEntryOptions()
                .SetSlidingExpiration(TimeSpan.FromMinutes(cacheDuration));

            await distributedCache.SetAsync(basket.BasketId.ToString(), serializedBasket, options);

            return true;
        }

        #endregion

        #region Basket Lines

        public async Task<IEnumerable<BasketLine>> GetBasketLines(Guid basketId)
        {
            var basket = await this.GetBasketById(basketId);
            return basket.BasketLines;
        }

        public async Task<BasketLine> GetBasketLineById(Guid basketId, Guid basketLineId)
        {
            var basket = await this.GetBasketById(basketId);
            var basketLine = basket.BasketLines.FirstOrDefault(line => line.BasketLineId == basketLineId);

            return basketLine;
        }

        public async Task<BasketLine> AddOrUpdateBasketLine(Guid basketId, BasketLine basketLine)
        {
            var basket = await this.GetBasketById(basketId);

            if (basket.BasketLines == null)
            {
                basket.BasketLines = new Collection<BasketLine>();
            }

            var existingLine = basket.BasketLines.FirstOrDefault(line => line.BasketLineId == basketLine.BasketLineId);

            if (existingLine == null)
            {
                // create new basket line

                basketLine.BasketId = basketId;
                basketLine.BasketLineId = Guid.NewGuid();

                basket.BasketLines.Add(basketLine);
            }
            else
            {
                // update existing basket line

                existingLine.Event = basketLine.Event;
                existingLine.EventId = basketLine.EventId;
                existingLine.Price = basketLine.Price;
                existingLine.TicketAmount = basketLine.TicketAmount;
            }

            await this.SaveChanges(basket);

            return basketLine;

        }

        public async void RemoveBasketLine(BasketLine basketLine)
        {
            var basket = await this.GetBasketById(basketLine.BasketId);

            if (basket.BasketLines == null)
            {
                basket.BasketLines = new Collection<BasketLine>();
            }

            var existingLine = basket.BasketLines.FirstOrDefault(line => line.BasketLineId == basketLine.BasketLineId);

            if (existingLine != null)
            {
                basket.BasketLines.Remove(existingLine);
                await this.SaveChanges(basket);
            }

        }

        #endregion
    }
}
