﻿using AutoMapper;
using GloboTicket.Services.ShoppingBasket.Entities;
using GloboTicket.Services.ShoppingBasket.Models;
using GloboTicket.Services.ShoppingBasket.Repositories;
using GloboTicket.Services.ShoppingBasket.Services;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using BasketLine = GloboTicket.Services.ShoppingBasket.Models.BasketLine;

namespace GloboTicket.Services.ShoppingBasket.Controllers
{
    [Route("api/baskets/{basketId}/basketlines")]
    [ApiController]
    public class BasketLinesController : ControllerBase
    {
        private readonly IBasketRepository basketRepository;
        private readonly IEventCatalogService eventCatalogService;
        private readonly IMapper mapper;

        public BasketLinesController(IBasketRepository basketRepository,
            IEventCatalogService eventCatalogService, IMapper mapper)
        {
            this.basketRepository = basketRepository;
            this.eventCatalogService = eventCatalogService;
            this.mapper = mapper;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<BasketLine>>> Get(Guid basketId)
        {
            if (!await basketRepository.BasketExists(basketId))
            {
                return NotFound();
            }

            var basketLines = await basketRepository.GetBasketLines(basketId);
            return Ok(mapper.Map<IEnumerable<BasketLine>>(basketLines));
        }

        [HttpGet("{basketLineId}", Name = "GetBasketLine")]
        public async Task<ActionResult<BasketLine>> Get(Guid basketId,
            Guid basketLineId)
        {
            if (!await basketRepository.BasketExists(basketId))
            {
                return NotFound();
            }

            var basketLine = await basketRepository.GetBasketLineById(basketId, basketLineId);
            if (basketLine == null)
            {
                return NotFound();
            }

            return Ok(mapper.Map<BasketLine>(basketLine));
        }

        [HttpPost]
        public async Task<ActionResult<BasketLine>> Post(Guid basketId, [FromBody] BasketLineForCreation basketLineForCreation)
        {
            var basket = await basketRepository.GetBasketById(basketId);

            if (basket == null)
            {
                return NotFound();
            }

            // get the event details object from the Event microservice
            var eventFromCatalog = await eventCatalogService.GetEvent(basketLineForCreation.EventId);

            // create BasketLine object from Dto passed into method
            var basketLineEntity = mapper.Map<Entities.BasketLine>(basketLineForCreation);

            basketLineEntity.Event = eventFromCatalog;

            var processedBasketLine = await basketRepository.AddOrUpdateBasketLine(basketId, basketLineEntity);

            var basketLineToReturn = mapper.Map<BasketLine>(processedBasketLine);

            return CreatedAtRoute(
                "GetBasketLine",
                new { basketId = basketLineEntity.BasketId, basketLineId = basketLineEntity.BasketLineId },
                basketLineToReturn);
        }

        [HttpPut("{basketLineId}")]
        public async Task<ActionResult<BasketLine>> Put(Guid basketId,
            Guid basketLineId,
            [FromBody] BasketLineForUpdate basketLineForUpdate)
        {
            if (!await basketRepository.BasketExists(basketId))
            {
                return NotFound();
            }

            var basketLineEntity = await basketRepository.GetBasketLineById(basketId, basketLineId);

            if (basketLineEntity == null)
            {
                return NotFound();
            }

            mapper.Map(basketLineForUpdate, basketLineEntity);

            await basketRepository.AddOrUpdateBasketLine(basketId, basketLineEntity);

            return Ok(mapper.Map<BasketLine>(basketLineEntity));
        }

        [HttpDelete("{basketLineId}")]
        public async Task<IActionResult> Delete(Guid basketId, Guid basketLineId)
        {

            var basket = await basketRepository.GetBasketById(basketId);

            if (basket == null)
            {
                return NotFound();
            }

            var basketLineEntity = await basketRepository.GetBasketLineById(basketId, basketLineId);

            if (basketLineEntity == null)
            {
                return NotFound();
            }

            basketRepository.RemoveBasketLine(basketLineEntity);

            return NoContent();
        }
    }
}
